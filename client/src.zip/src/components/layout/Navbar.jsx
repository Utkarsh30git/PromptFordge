import { useState } from "react";
import { NAV_LINKS } from "../../constants/navigation";
import Button from "../ui/Button";
import useAuthStore from "../../store/authStore";

const Navbar = () => {
  const user = useAuthStore((state) => state.user);
  const logout = useAuthStore((state) => state.logout);

  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <nav>
      <div className="nav-inner">

        {/* Logo */}
        <div className="logo">
          <span className="logo-dot"></span>
          PromptForge
        </div>

        {/* Navigation Links */}
        <div className="nav-links">
          {NAV_LINKS.map((link) => (
            <a key={link.name} href={link.href}>
              {link.name}
            </a>
          ))}
        </div>

        {/* Navigation Actions */}
        <div className="nav-actions">

          {!user ? (
            <>
              <Button
                variant="ghost"
                onClick={() => {
                  window.open(
                    "https://github.com",
                    "_blank"
                  );
                }}
              >
                Github
              </Button>

              <Button
                variant="amber"
                onClick={() => {
                  window.location.href = "/login";
                }}
              >
                Get Started
              </Button>
            </>
          ) : (
            <div className="user-menu">

              <button
                className="user-trigger"
                onClick={() => setMenuOpen(!menuOpen)}
              >
                {user.avatar ? (
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="user-avatar"
                  />
                ) : (
                  <span className="user-avatar-fallback">
                    {user.name?.charAt(0).toUpperCase()}
                  </span>
                )}

                <span className="user-name">
                  {user.name}
                </span>

                <span className="user-chevron">
                  ▾
                </span>
              </button>

              {menuOpen && (
                <div className="user-dropdown">

                  <div className="user-info">
                    <strong>{user.name}</strong>

                    <span>{user.email}</span>
                  </div>

                  <div className="dropdown-divider"></div>

                  <button
                    className="dropdown-item"
                    onClick={() => {
                      window.location.href = "/dashboard";
                    }}
                  >
                    Dashboard
                  </button>

                  <button
                    className="dropdown-item"
                    onClick={() => {
                      window.location.href = "/workspace";
                    }}
                  >
                    Workspace
                  </button>

                  <button
                    className="dropdown-item logout"
                    onClick={async () => {
                      await logout();
                      setMenuOpen(false);
                    }}
                  >
                    Logout
                  </button>

                </div>
              )}
            </div>
          )}

        </div>
      </div>
    </nav>
  );
};

export default Navbar;